#!/bin/bash

set -u

# ------------------------------------------------------------------
# Base directory for isolated toolchains (nvm, pnpm, maven, gradle).
#
#   - 42 school Linux machines: /goinfre/$USER (home quota is tiny,
#     goinfre is the large scratch disk meant for this).
#   - Anywhere else (personal Mac, personal Linux, CI, ...):
#     $HOME/.springstarter, unless SPRINGSTARTER_HOME is set.
#
# Override manually with: SPRINGSTARTER_HOME=/some/path ./setup.sh
# ------------------------------------------------------------------
if [ -n "${SPRINGSTARTER_HOME:-}" ]; then
    BASE="$SPRINGSTARTER_HOME"
elif [ -d "/goinfre" ]; then
    BASE="/goinfre/$USER"
else
    BASE="$HOME/.springstarter"
fi

OS="$(uname -s)"
NVM_DIR="$BASE/.nvm"
PNPM_HOME="$BASE/pnpm"
MAVEN_REPO="$BASE/maven-repo"
GRADLE_HOME="$BASE/gradle"
ENV_FILE="$BASE/springstarter-env.sh"

echo "=============================================="
echo "  SpringStarter - environment setup"
echo "  OS:   $OS"
echo "  Base: $BASE"
echo "=============================================="

mkdir -p "$BASE" "$MAVEN_REPO" "$PNPM_HOME" "$GRADLE_HOME" "$HOME/.m2"

if [ -n "${NPM_CONFIG_PREFIX:-}" ]; then
    unset NPM_CONFIG_PREFIX
fi

# --- nvm + Node 24 ---------------------------------------------------
if [ ! -s "$NVM_DIR/nvm.sh" ]; then
    echo "Installing nvm..."
    git clone --depth 1 https://github.com/nvm-sh/nvm.git "$NVM_DIR"
else
    echo "nvm already installed."
fi

export NVM_DIR
# shellcheck disable=SC1090
. "$NVM_DIR/nvm.sh"

if nvm ls 24 2>/dev/null | grep -q "v24"; then
    echo "Node 24 already installed."
else
    echo "Installing Node 24..."
    nvm install 24
fi

nvm use 24 >/dev/null 2>&1 || true
nvm alias default 24 >/dev/null 2>&1 || true

# --- pnpm --------------------------------------------------------------
export PNPM_HOME
export PATH="$PNPM_HOME:$PATH"

if ! command -v pnpm >/dev/null 2>&1; then
    echo "Installing pnpm..."
    curl -fsSL https://get.pnpm.io/install.sh | env PNPM_HOME="$PNPM_HOME" SHELL="$(command -v zsh 2>/dev/null || command -v bash)" sh -
fi

mkdir -p "$BASE/pnpm-store"

# --- Maven -------------------------------------------------------------
cat > "$HOME/.m2/settings.xml" <<EOF
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 https://maven.apache.org/xsd/settings-1.0.0.xsd">
  <localRepository>$MAVEN_REPO</localRepository>
</settings>
EOF

# --- Shared env file (sourced by shell, and picked up by `make`) ------
cat > "$ENV_FILE" <<EOF
export MAVEN_OPTS="-Dmaven.repo.local=$MAVEN_REPO"
export GRADLE_USER_HOME="$GRADLE_HOME"
export PNPM_HOME="$PNPM_HOME"
export NVM_DIR="$NVM_DIR"
export PATH="\$PNPM_HOME:\$PATH"
[ -s "\$NVM_DIR/nvm.sh" ] && \. "\$NVM_DIR/nvm.sh"
EOF

echo ""
echo "Setup complete."
echo "Add this to your shell profile (~/.zshrc, ~/.bashrc, ...) if desired:"
echo "  source $ENV_FILE"
echo ""
echo "Then run: make up"
