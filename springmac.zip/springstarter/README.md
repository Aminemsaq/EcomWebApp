# SpringStarter

A small reusable Spring Boot + React starter, blank/virgin base ready for a new project, using:

- Java 21
- Spring Boot
- Maven
- PostgreSQL
- React + Vite
- Node 24
- Docker Compose
- Make

## Prerequisites

- **Docker path (`make up`)**: only Docker + Docker Compose. Works identically on Mac and Linux — everything else (JDK 21, Maven, Node) runs inside the containers.
- **Local/no-Docker path (`make backend` / `make frontend`)**: you need `git`, `curl`, a JDK 21, and Maven (`mvn`) installed on the host — `setup.sh` only isolates Node/pnpm (via nvm) and points Maven/Gradle at a local repo, it doesn't install the JDK or Maven binary itself.
  - Mac: `brew install openjdk@21 maven`
  - 42 school machines: JDK 21 + Maven are already provided by the school image.

## Quick start (Docker — works the same on Mac and Linux)

```bash
make up
```

Services:

- Frontend: http://localhost:5173
- Backend: http://localhost:8080
- PostgreSQL: localhost:5432

## Local development (without Docker)

`setup.sh` installs an isolated Node/pnpm/Maven/Gradle toolchain so it never touches your system-wide versions. It auto-detects where to put it:

- On 42 school machines (`/goinfre` present): `/goinfre/$USER`
- On a personal Mac or any other machine: `$HOME/.springstarter`
- Or force a location: `SPRINGSTARTER_HOME=/some/path ./setup.sh`

```bash
chmod +x setup.sh
make setup
```

`make setup` prints a `source ...` line at the end — run it (or add it to your `~/.zshrc`/`~/.bashrc`) to load the toolchain into your shell:

- Personal Mac/Linux: `source $HOME/.springstarter/springstarter-env.sh`
- 42 school machine: `source /goinfre/$USER/springstarter-env.sh`

Backend:

```bash
make db
make backend
```

Frontend:

```bash
make frontend
```

## Useful commands

```bash
make up
make down
make restart
make logs
make ps
make build
make test
make clean
make fclean
```

## Starting point

This project intentionally contains **no business logic** — just the Spring Boot bootstrap, database wiring, and a blank React shell. `ddl-auto: update` is on, so any `@Entity` you add is auto-migrated to the `starter_db` Postgres instance on startup.

Recommended progression when building on top of it:

1. Entity
2. Repository
3. DTO
4. Mapper
5. Service
6. Controller
7. Validation
8. Exception handling
9. Pagination
10. Authentication
11. Authorization
12. Unit tests
13. Integration tests

Copy this folder whenever you start a new backend/frontend project.
